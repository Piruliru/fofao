/*
	This is a service worker file, but is not used. It exists solely to trigger
	the Web App install banner in Chrome, which requires there to be a service worker
	registered. See: http://updates.html5rocks.com/2015/03/increasing-engagement-with-app-install-banners-in-chrome-for-android
*/